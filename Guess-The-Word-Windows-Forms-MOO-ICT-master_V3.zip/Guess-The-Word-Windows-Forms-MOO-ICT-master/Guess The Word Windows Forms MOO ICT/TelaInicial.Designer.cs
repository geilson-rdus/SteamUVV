﻿namespace Guess_The_Word_Windows_Forms_MOO_ICT
{
    partial class TelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            InsiraNome = new Label();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // InsiraNome
            // 
            InsiraNome.AutoSize = true;
            InsiraNome.Font = new Font("GenEi Kiwami Gothic Ultra", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            InsiraNome.ForeColor = SystemColors.ControlText;
            InsiraNome.Location = new Point(188, 162);
            InsiraNome.Name = "InsiraNome";
            InsiraNome.Size = new Size(424, 24);
            InsiraNome.TabIndex = 0;
            InsiraNome.Text = "Insira seu nome (deve ter 5 letras) ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("GenEi Kiwami Gothic Ultra", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(285, 217);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(219, 25);
            textBox1.TabIndex = 1;
            textBox1.KeyPress += KeyPress;
            // 
            // TelaInicial
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(InsiraNome);
            Name = "TelaInicial";
            Text = "TelaInicial";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label InsiraNome;
        private TextBox textBox1;
    }
}
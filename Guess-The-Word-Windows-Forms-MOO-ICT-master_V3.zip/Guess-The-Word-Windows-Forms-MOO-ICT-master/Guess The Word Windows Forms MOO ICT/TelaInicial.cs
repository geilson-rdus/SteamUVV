﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Guess_The_Word_Windows_Forms_MOO_ICT
{
    public partial class TelaInicial : Form
    {
        public string nome;
        public TelaInicial()
        {
            InitializeComponent();
        }

        private void KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox1.MaxLength = 5;


            if (e.KeyChar == (char)Keys.Enter && textBox1.TextLength == 5)
            {
                nome = textBox1.Text;
                this.Close();
            }
            else if (e.KeyChar == (char)Keys.Enter)
            {
                MessageBox.Show("Ooops, not so fast! A palavra deve ter 5 letras!");
            }
        }
    }
}

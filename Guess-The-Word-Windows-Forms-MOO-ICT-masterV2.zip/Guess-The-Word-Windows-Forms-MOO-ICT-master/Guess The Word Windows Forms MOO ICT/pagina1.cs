﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Guess_The_Word_Windows_Forms_MOO_ICT
{
    public partial class pagina1 : Form
    {
        public pagina1()
        {
            InitializeComponent();
        }

        private void IrParaJogo_Click(object sender, EventArgs e)
        {
           
            this.Close();
        }
    }
}

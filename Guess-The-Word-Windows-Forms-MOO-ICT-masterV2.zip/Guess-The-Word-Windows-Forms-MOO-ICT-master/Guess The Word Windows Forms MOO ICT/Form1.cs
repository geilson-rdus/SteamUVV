using System.Diagnostics.Eventing.Reader;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Guess_The_Word_Windows_Forms_MOO_ICT
{

    // Made by MOO ICT
    // For educational purpose only
    public partial class Form1 : Form
    {

        List<string> words = new List<string>();
        string newText;
        int i = 0;
        int guessed = 0;


        public Form1()
        {
            InitializeComponent();
            Setup();

        }


        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            textBox1.MaxLength = 5;


            if (e.KeyChar == (char)Keys.Enter && textBox1.TextLength == 5)
            {

                if (words[i].ToLower() == textBox1.Text.ToLower())
                {
                    if (i < words.Count - 1)
                    {
                        MessageBox.Show("Correct!", "Moo Says: ");
                        textBox1.Text = "";
                        i += 1;
                        newText = Scramble(words[i]);
                        lblWord.Text = newText;
                        lblInfo.Text = "Words: " + (i + 1) + " of " + words.Count;
                        guessed = 0;
                        lblGussed.Text = "Guessed: " + guessed + " times.";
                    }
                    else
                    {
                        lblWord.Text = "You Win, Well done";
                        return;
                    }
                }
                else if(guessed<6)
                {
                    guessed += 1;
                    lblGussed.Text = "Guessed: " + guessed + " times.";
                }else if (guessed >= 6)
                {
                    MessageBox.Show("GAME OVER ");
                }
                e.Handled = true;

            }
            else if(e.KeyChar == (char)Keys.Enter)
            {
                MessageBox.Show("Ooops, not so fast! A palavra deve ter 5 letras!");
            }
        }

        private void Setup()
        {
            words = File.ReadLines("words.txt").ToList();
            newText = Scramble(words[i]);
            lblWord.Text = newText;
            lblInfo.Text = "Words: " + (i + 1) + " of " + words.Count;

        }

        private string Scramble(string text)
        {
            return new string(text.ToCharArray().OrderBy(x => Guid.NewGuid()).ToArray());
        }

        private void RegrasPagina_Click(object sender, EventArgs e)
        {
            pagina1 pag1= new pagina1();
            pag1.Show();
        }
    }
}
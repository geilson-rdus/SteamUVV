﻿namespace Guess_The_Word_Windows_Forms_MOO_ICT
{
    partial class pagina1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            IrParaJogo = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // IrParaJogo
            // 
            IrParaJogo.Location = new Point(331, 295);
            IrParaJogo.Name = "IrParaJogo";
            IrParaJogo.Size = new Size(112, 34);
            IrParaJogo.TabIndex = 0;
            IrParaJogo.Text = "button1";
            IrParaJogo.UseVisualStyleBackColor = true;
            IrParaJogo.Click += IrParaJogo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(319, 71);
            label1.Name = "label1";
            label1.Size = new Size(100, 25);
            label1.TabIndex = 1;
            label1.Text = "Regras TBC";
            // 
            // pagina1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(IrParaJogo);
            Name = "pagina1";
            Text = "pagina1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button IrParaJogo;
        private Label label1;
    }
}